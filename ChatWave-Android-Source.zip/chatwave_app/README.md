# ChatWave

A Telegram-inspired Android chat demo built with Kotlin + Jetpack Compose.

## Included
- Telegram-like chat list and message screen
- Local message sending and persistence
- Search
- New-chat contact picker
- Saved Messages and demo contacts
- Light / dark theme
- Unread badges and timestamps
- GitHub Actions APK build

## Build on GitHub
1. Create an empty GitHub repository.
2. Upload this project to the repository root.
3. Open **Actions → Build Android APK → Run workflow**.
4. When the workflow finishes, download the **ChatWave-debug-apk** artifact.
5. Extract the ZIP and install `app-debug.apk` on Android.

This first version is local/offline. A real multi-user messenger needs a backend for authentication, message delivery, media storage, push notifications, presence, and security.
