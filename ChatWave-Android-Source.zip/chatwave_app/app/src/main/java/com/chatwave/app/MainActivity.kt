package com.chatwave.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ChatWaveApp() }
    }
}

data class Chat(
    val id: Int,
    val name: String,
    val initials: String,
    val color: Long,
    val online: Boolean = false,
    val muted: Boolean = false,
    val pinned: Boolean = false,
    val isBot: Boolean = false
)

data class Message(
    val id: Long,
    val chatId: Int,
    val text: String,
    val mine: Boolean,
    val timestamp: Long,
    val read: Boolean = true
)

enum class Screen { Chats, Settings, Contacts, Saved }

private val telegramBlue = Color(0xFF229ED9)
private val bubbleBlue = Color(0xFFE3F2FD)
private val bubbleGreen = Color(0xFFE6F7D9)

private val seedChats = listOf(
    Chat(1, "Alex Morgan", "AM", 0xFF5C6BC0, online = true, pinned = true),
    Chat(2, "Design Team", "DT", 0xFF26A69A, muted = true, pinned = true),
    Chat(3, "Mina", "M", 0xFFEC407A, online = true),
    Chat(4, "Family", "F", 0xFF7E57C2),
    Chat(5, "Demo Bot", "DB", 0xFF42A5F5, isBot = true),
    Chat(99, "Saved Messages", "★", 0xFF229ED9, pinned = true)
)

private val seedMessages = listOf(
    Message(1, 1, "Hey! This app already feels familiar 😄", false, System.currentTimeMillis() - 3_600_000),
    Message(2, 1, "That was the idea. Clean and fast.", true, System.currentTimeMillis() - 3_300_000),
    Message(3, 2, "I uploaded the latest mockups.", false, System.currentTimeMillis() - 7_200_000),
    Message(4, 3, "See you tomorrow!", false, System.currentTimeMillis() - 86_400_000),
    Message(5, 4, "Dinner at 8?", false, System.currentTimeMillis() - 172_800_000),
    Message(6, 5, "Hello! Send me a message and I’ll answer locally.", false, System.currentTimeMillis() - 900_000),
    Message(7, 99, "Use this chat as your personal notes.", false, System.currentTimeMillis() - 500_000)
)

class LocalStore(context: Context) {
    private val prefs = context.getSharedPreferences("chatwave", Context.MODE_PRIVATE)

    fun loadMessages(): MutableList<Message> {
        val raw = prefs.getString("messages", null) ?: return seedMessages.toMutableList()
        return runCatching {
            val arr = JSONArray(raw)
            MutableList(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                Message(
                    id = o.getLong("id"),
                    chatId = o.getInt("chatId"),
                    text = o.getString("text"),
                    mine = o.getBoolean("mine"),
                    timestamp = o.getLong("timestamp"),
                    read = o.optBoolean("read", true)
                )
            }
        }.getOrElse { seedMessages.toMutableList() }
    }

    fun saveMessages(messages: List<Message>) {
        val arr = JSONArray()
        messages.forEach { m ->
            arr.put(JSONObject().apply {
                put("id", m.id)
                put("chatId", m.chatId)
                put("text", m.text)
                put("mine", m.mine)
                put("timestamp", m.timestamp)
                put("read", m.read)
            })
        }
        prefs.edit().putString("messages", arr.toString()).apply()
    }

    fun darkMode(): Boolean = prefs.getBoolean("dark", false)
    fun setDarkMode(value: Boolean) = prefs.edit().putBoolean("dark", value).apply()
}

@Composable
fun ChatWaveApp() {
    val context = LocalContext.current
    val store = remember { LocalStore(context) }
    var darkMode by rememberSaveable { mutableStateOf(store.darkMode()) }
    val messages = remember { mutableStateListOf<Message>().apply { addAll(store.loadMessages()) } }
    var currentScreen by rememberSaveable { mutableStateOf(Screen.Chats) }
    var openedChatId by rememberSaveable { mutableStateOf<Int?>(null) }

    val scheme = if (darkMode) {
        darkColorScheme(
            primary = Color(0xFF64B5F6),
            secondary = Color(0xFF90CAF9),
            surface = Color(0xFF17212B),
            background = Color(0xFF0E1621)
        )
    } else {
        lightColorScheme(
            primary = telegramBlue,
            secondary = telegramBlue,
            background = Color(0xFFF4F4F5),
            surface = Color.White
        )
    }

    MaterialTheme(colorScheme = scheme) {
        Surface(modifier = Modifier.fillMaxSize()) {
            val chat = openedChatId?.let { id -> seedChats.firstOrNull { it.id == id } }
            if (chat != null) {
                ChatScreen(
                    chat = chat,
                    allMessages = messages,
                    onBack = { openedChatId = null },
                    onSend = { text ->
                        val newMessage = Message(
                            id = System.currentTimeMillis(),
                            chatId = chat.id,
                            text = text,
                            mine = true,
                            timestamp = System.currentTimeMillis()
                        )
                        messages.add(newMessage)
                        store.saveMessages(messages)
                    },
                    onBotReply = { text ->
                        messages.add(
                            Message(
                                id = System.currentTimeMillis() + 1,
                                chatId = chat.id,
                                text = text,
                                mine = false,
                                timestamp = System.currentTimeMillis()
                            )
                        )
                        store.saveMessages(messages)
                    }
                )
            } else {
                HomeShell(
                    screen = currentScreen,
                    messages = messages,
                    darkMode = darkMode,
                    onToggleDark = {
                        darkMode = it
                        store.setDarkMode(it)
                    },
                    onScreenChange = { currentScreen = it },
                    onOpenChat = { openedChatId = it }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeShell(
    screen: Screen,
    messages: List<Message>,
    darkMode: Boolean,
    onToggleDark: (Boolean) -> Unit,
    onScreenChange: (Screen) -> Unit,
    onOpenChat: (Int) -> Unit
) {
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(modifier = Modifier.width(310.dp)) {
                DrawerHeader()
                NavigationDrawerItem(
                    label = { Text("New Group") },
                    selected = false,
                    onClick = { scope.launch { drawerState.close() } },
                    icon = { Icon(Icons.Outlined.GroupAdd, null) }
                )
                NavigationDrawerItem(
                    label = { Text("Contacts") },
                    selected = screen == Screen.Contacts,
                    onClick = {
                        onScreenChange(Screen.Contacts)
                        scope.launch { drawerState.close() }
                    },
                    icon = { Icon(Icons.Outlined.Contacts, null) }
                )
                NavigationDrawerItem(
                    label = { Text("Calls") },
                    selected = false,
                    onClick = { scope.launch { drawerState.close() } },
                    icon = { Icon(Icons.Outlined.Call, null) }
                )
                NavigationDrawerItem(
                    label = { Text("Saved Messages") },
                    selected = screen == Screen.Saved,
                    onClick = {
                        onScreenChange(Screen.Saved)
                        scope.launch { drawerState.close() }
                    },
                    icon = { Icon(Icons.Outlined.BookmarkBorder, null) }
                )
                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                NavigationDrawerItem(
                    label = { Text("Settings") },
                    selected = screen == Screen.Settings,
                    onClick = {
                        onScreenChange(Screen.Settings)
                        scope.launch { drawerState.close() }
                    },
                    icon = { Icon(Icons.Outlined.Settings, null) }
                )
            }
        }
    ) {
        when (screen) {
            Screen.Chats -> ChatsScreen(
                messages = messages,
                onMenu = { scope.launch { drawerState.open() } },
                onOpenChat = onOpenChat,
                onSettings = { onScreenChange(Screen.Settings) }
            )
            Screen.Settings -> SettingsScreen(
                darkMode = darkMode,
                onToggleDark = onToggleDark,
                onBack = { onScreenChange(Screen.Chats) }
            )
            Screen.Contacts -> ContactsScreen(
                onBack = { onScreenChange(Screen.Chats) },
                onOpenChat = onOpenChat
            )
            Screen.Saved -> {
                LaunchedEffect(Unit) { onOpenChat(99) }
                Box(Modifier.fillMaxSize())
            }
        }
    }
}

@Composable
fun DrawerHeader() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.primary)
            .padding(24.dp)
    ) {
        Box(
            modifier = Modifier
                .size(68.dp)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.18f)),
            contentAlignment = Alignment.Center
        ) {
            Text("CW", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(14.dp))
        Text("ChatWave User", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
        Text("+000 000 0000", color = Color.White.copy(alpha = 0.85f), fontSize = 14.sp)
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun ChatsScreen(
    messages: List<Message>,
    onMenu: () -> Unit,
    onOpenChat: (Int) -> Unit,
    onSettings: () -> Unit
) {
    var searching by rememberSaveable { mutableStateOf(false) }
    var query by rememberSaveable { mutableStateOf("") }
    var showNewChat by rememberSaveable { mutableStateOf(false) }

    val visibleChats = remember(query) {
        if (query.isBlank()) seedChats
        else seedChats.filter { it.name.contains(query, ignoreCase = true) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    if (searching) {
                        TextField(
                            value = query,
                            onValueChange = { query = it },
                            placeholder = { Text("Search") },
                            singleLine = true,
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent,
                                focusedIndicatorColor = Color.Transparent,
                                unfocusedIndicatorColor = Color.Transparent
                            )
                        )
                    } else {
                        Text("ChatWave", fontWeight = FontWeight.SemiBold)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = {
                        if (searching) {
                            searching = false
                            query = ""
                        } else onMenu()
                    }) {
                        Icon(if (searching) Icons.Default.ArrowBack else Icons.Default.Menu, null)
                    }
                },
                actions = {
                    if (!searching) {
                        IconButton(onClick = { searching = true }) { Icon(Icons.Default.Search, null) }
                        IconButton(onClick = onSettings) { Icon(Icons.Default.MoreVert, null) }
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showNewChat = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = Color.White,
                shape = CircleShape
            ) { Icon(Icons.Default.Edit, "New message") }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.surface)
        ) {
            items(visibleChats, key = { it.id }) { chat ->
                val latest = messages.filter { it.chatId == chat.id }.maxByOrNull { it.timestamp }
                ChatRow(chat, latest, onOpen = { onOpenChat(chat.id) })
            }
            item { Spacer(Modifier.height(88.dp)) }
        }
    }

    if (showNewChat) {
        ModalBottomSheet(onDismissRequest = { showNewChat = false }) {
            Text(
                "New Message",
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
                fontSize = 20.sp,
                fontWeight = FontWeight.SemiBold
            )
            seedChats.filter { it.id != 99 }.forEach { chat ->
                ListItem(
                    headlineContent = { Text(chat.name) },
                    supportingContent = { Text(if (chat.online) "online" else "last seen recently") },
                    leadingContent = { Avatar(chat) },
                    modifier = Modifier.combinedClickable(
                        onClick = {
                            showNewChat = false
                            onOpenChat(chat.id)
                        },
                        onLongClick = {}
                    )
                )
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ChatRow(chat: Chat, latest: Message?, onOpen: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .combinedClickable(onClick = onOpen, onLongClick = {})
            .padding(horizontal = 12.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Avatar(chat)
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    chat.name,
                    fontSize = 16.5.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (latest != null) {
                    Text(
                        shortTime(latest.timestamp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 12.sp
                    )
                }
            }
            Spacer(Modifier.height(3.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (latest?.mine == true) {
                    Icon(
                        Icons.Default.DoneAll,
                        contentDescription = null,
                        tint = telegramBlue,
                        modifier = Modifier.size(17.dp)
                    )
                    Spacer(Modifier.width(3.dp))
                }
                Text(
                    latest?.text ?: "No messages yet",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                    fontSize = 14.5.sp
                )
                if (chat.pinned) {
                    Icon(
                        Icons.Default.PushPin,
                        null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(16.dp)
                    )
                }
                if (chat.muted) {
                    Spacer(Modifier.width(5.dp))
                    Icon(
                        Icons.Default.VolumeOff,
                        null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun Avatar(chat: Chat) {
    Box(
        modifier = Modifier
            .size(54.dp)
            .clip(CircleShape)
            .background(Color(chat.color)),
        contentAlignment = Alignment.Center
    ) {
        Text(chat.initials, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    chat: Chat,
    allMessages: List<Message>,
    onBack: () -> Unit,
    onSend: (String) -> Unit,
    onBotReply: (String) -> Unit
) {
    var text by rememberSaveable { mutableStateOf("") }
    var typing by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val chatMessages = allMessages.filter { it.chatId == chat.id }.sortedBy { it.timestamp }

    LaunchedEffect(chatMessages.size) {
        if (chatMessages.isNotEmpty()) listState.animateScrollToItem(chatMessages.lastIndex)
    }

    fun send() {
        val value = text.trim()
        if (value.isEmpty()) return
        text = ""
        onSend(value)
        if (chat.isBot) {
            typing = true
            scope.launch {
                delay(850)
                onBotReply(botReply(value))
                typing = false
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        AvatarSmall(chat)
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(chat.name, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                            Text(
                                when {
                                    typing -> "typing…"
                                    chat.isBot -> "bot"
                                    chat.online -> "online"
                                    else -> "last seen recently"
                                },
                                color = if (chat.online || typing) telegramBlue else MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 12.sp
                            )
                        }
                    }
                },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) } },
                actions = {
                    IconButton(onClick = {}) { Icon(Icons.Outlined.Call, null) }
                    IconButton(onClick = {}) { Icon(Icons.Default.MoreVert, null) }
                }
            )
        },
        bottomBar = {
            MessageComposer(
                text = text,
                onTextChange = { text = it },
                onSend = ::send
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                items(chatMessages, key = { it.id }) { message ->
                    MessageBubble(message)
                }
                if (typing) {
                    item {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
                            Surface(
                                shape = RoundedCornerShape(18.dp, 18.dp, 18.dp, 5.dp),
                                color = MaterialTheme.colorScheme.surface
                            ) {
                                Text("•••", modifier = Modifier.padding(horizontal = 16.dp, vertical = 9.dp), letterSpacing = 2.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AvatarSmall(chat: Chat) {
    Box(
        modifier = Modifier.size(38.dp).clip(CircleShape).background(Color(chat.color)),
        contentAlignment = Alignment.Center
    ) {
        Text(chat.initials, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun MessageBubble(message: Message) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (message.mine) Arrangement.End else Arrangement.Start
    ) {
        Surface(
            shape = if (message.mine)
                RoundedCornerShape(18.dp, 18.dp, 5.dp, 18.dp)
            else RoundedCornerShape(18.dp, 18.dp, 18.dp, 5.dp),
            color = if (message.mine) {
                if (MaterialTheme.colorScheme.background.luminanceApprox() < .5f) Color(0xFF2B5278) else bubbleGreen
            } else MaterialTheme.colorScheme.surface,
            tonalElevation = 1.dp,
            modifier = Modifier.widthIn(max = 310.dp)
        ) {
            Row(
                modifier = Modifier.padding(start = 11.dp, end = 7.dp, top = 7.dp, bottom = 5.dp),
                verticalAlignment = Alignment.Bottom
            ) {
                Text(message.text, modifier = Modifier.weight(1f, fill = false), fontSize = 15.sp)
                Spacer(Modifier.width(8.dp))
                Text(shortTime(message.timestamp), fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (message.mine) {
                    Spacer(Modifier.width(2.dp))
                    Icon(
                        Icons.Default.DoneAll,
                        null,
                        modifier = Modifier.size(15.dp),
                        tint = telegramBlue
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MessageComposer(text: String, onTextChange: (String) -> Unit, onSend: () -> Unit) {
    Surface(tonalElevation = 2.dp) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 7.dp, vertical = 6.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            IconButton(onClick = {}) { Icon(Icons.Outlined.SentimentSatisfiedAlt, null) }
            TextField(
                value = text,
                onValueChange = onTextChange,
                modifier = Modifier.weight(1f),
                placeholder = { Text("Message") },
                minLines = 1,
                maxLines = 5,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { onSend() }),
                shape = RoundedCornerShape(24.dp),
                colors = TextFieldDefaults.colors(
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    disabledIndicatorColor = Color.Transparent
                ),
                trailingIcon = {
                    IconButton(onClick = {}) { Icon(Icons.Outlined.AttachFile, null) }
                }
            )
            Spacer(Modifier.width(5.dp))
            FloatingActionButton(
                onClick = onSend,
                modifier = Modifier.size(48.dp),
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = Color.White,
                shape = CircleShape
            ) {
                Icon(if (text.isBlank()) Icons.Default.Mic else Icons.Default.Send, null)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(darkMode: Boolean, onToggleDark: (Boolean) -> Unit, onBack: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) } }
            )
        }
    ) { padding ->
        LazyColumn(modifier = Modifier.padding(padding)) {
            item {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier.size(86.dp).clip(CircleShape).background(telegramBlue),
                        contentAlignment = Alignment.Center
                    ) { Text("CW", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold) }
                    Spacer(Modifier.height(12.dp))
                    Text("ChatWave User", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                    Text("+000 000 0000", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            item { HorizontalDivider() }
            item {
                ListItem(
                    headlineContent = { Text("Dark Mode") },
                    supportingContent = { Text("Switch between light and dark appearance") },
                    leadingContent = { Icon(Icons.Outlined.DarkMode, null) },
                    trailingContent = { Switch(checked = darkMode, onCheckedChange = onToggleDark) }
                )
            }
            item {
                ListItem(
                    headlineContent = { Text("Notifications and Sounds") },
                    leadingContent = { Icon(Icons.Outlined.Notifications, null) }
                )
            }
            item {
                ListItem(
                    headlineContent = { Text("Privacy and Security") },
                    leadingContent = { Icon(Icons.Outlined.Lock, null) }
                )
            }
            item {
                ListItem(
                    headlineContent = { Text("Data and Storage") },
                    leadingContent = { Icon(Icons.Outlined.Storage, null) }
                )
            }
            item {
                ListItem(
                    headlineContent = { Text("Chat Settings") },
                    leadingContent = { Icon(Icons.Outlined.Chat, null) }
                )
            }
            item {
                Text(
                    "ChatWave 1.0.0 • local demo",
                    modifier = Modifier.fillMaxWidth().padding(24.dp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 13.sp
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun ContactsScreen(onBack: () -> Unit, onOpenChat: (Int) -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Contacts") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) } },
                actions = { IconButton(onClick = {}) { Icon(Icons.Default.Search, null) } }
            )
        }
    ) { padding ->
        LazyColumn(modifier = Modifier.padding(padding)) {
            item {
                ListItem(
                    headlineContent = { Text("Invite Friends") },
                    leadingContent = {
                        Box(Modifier.size(48.dp).clip(CircleShape).background(telegramBlue), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.PersonAdd, null, tint = Color.White)
                        }
                    }
                )
            }
            items(seedChats.filter { it.id != 99 }) { chat ->
                ListItem(
                    headlineContent = { Text(chat.name) },
                    supportingContent = { Text(if (chat.online) "online" else "last seen recently") },
                    leadingContent = { Avatar(chat) },
                    modifier = Modifier.combinedClickable(onClick = { onOpenChat(chat.id) }, onLongClick = {})
                )
            }
        }
    }
}

private fun shortTime(timestamp: Long): String =
    SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(timestamp))

private fun botReply(input: String): String {
    val t = input.lowercase(Locale.getDefault())
    return when {
        "hello" in t || "hi" in t || "سلام" in t -> "Hey! 👋 ChatWave is running locally on your phone."
        "time" in t || "ساعت" in t -> "Your device time is ${shortTime(System.currentTimeMillis())}."
        "telegram" in t -> "The interface is Telegram-inspired, but this is an independent demo app."
        else -> "You said: “$input”\n\nThis reply was generated locally by the demo bot."
    }
}

private fun Color.luminanceApprox(): Float =
    (red * 0.299f + green * 0.587f + blue * 0.114f)
